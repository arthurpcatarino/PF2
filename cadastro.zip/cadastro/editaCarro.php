<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Alteração de cadastro</title>
	<link href="css/cadastroCarro.css" rel="stylesheet">
  </head>
  <body>
    <!-- <?php
	  include 'conexao.php';
	
	  $id = $_GET['id'] ?? '';
	  $sql = "SELECT * FROM carros WHERE VC01_CD_CAR = $id";
	  
	  $dados = mysqli_query($conexao, $sql);
	  
	  
	  $linha = mysqli_fetch_assoc($dados);
	?> -->
  <div class="container">
    <div class="form-signin"> 
      <h3>Alteração de cadastro</h3>
      <form name="signup" method="post" class="form-signin" action="editando.php">
          <!--Proprietário-->
          <div class="form-group row">
            <div class="col-10">
              <input class="form-control" type="text" placeholder="Nome do proprietário">
            </div>
          </div>
          <!--Modelo-->
          <div class="form-group row">
            <div class="col-10">
              <input class="form-control" type="text" placeholder="Modelo">
            </div>
          </div>
          <!--Marca-->
          <div class="form-group row">
            <div class="col-10">
              <input class="form-control" type="text" placeholder="Marca">
            </div>
          </div>
          <!--Ano-->
          <div class="form-group row">
            <div class="col-10">
              <input class="date-own form-control" type="text" placeholder="Ano">
            </div>
          </div>
          <!--Cor-->
          <div class="form-group row">
            <div class="col-10">
              <input class="form-control" type="color" value="#563d7c" id="example-color-input">
            </div>
          </div>
           <!--Placa-->
           <div class="form-group row">
            <div class="col-10">
              <input class="form-control" type="text" placeholder="Placa">
            </div>
          </div>
           <!--Passageiros-->
           <div class="form-group row">
            <div class="col-10">
              <input class="form-control" type="text" placeholder="Passageiros">
            </div>
          </div>
           <!--Valor da Compra-->
           <div class="form-group row">
            <div class="col-10">
              <input class="form-control" type="text" id="amount" placeholder="Valor da Compra">
            </div>
          </div>
           <!--Kilometros Rodados-->
           <div class="form-group row">
            <div class="col-10">
              <input class="form-control" type="text" id="distance"  placeholder="Kilometros Rodados">
            </div>
          </div>
          
          <input type="submit" name="btnCadAutomovel" class="btn btn-success mr-5" value="Cadastrar"\>
          <a href="index.php" class="btn btn-success ml-5">Voltar</a>
      </form>
    </div>  
	</div>

  <script>
    $('.date-own').datepicker({
    format: "yyyy",
    viewMode: "years", 
    minViewMode: "years"
    });
    $(document).ready(function() {
    $("#amount").on("input", function() {
        // allow numbers, a comma or a dot
        var v= $(this).val(), vc = v.replace(/[^0-9,\.]/, '');
        if (v !== vc)        
            $(this).val(vc);
    });
    $("#distance").on("input", function() {
        // allow numbers, a comma or a dot
        var v= $(this).val(), vc = v.replace(/[^0-9,\.]/, '');
        if (v !== vc)        
            $(this).val(vc);
    });
});

  </script>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>	